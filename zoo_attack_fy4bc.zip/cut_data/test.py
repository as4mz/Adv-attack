import numpy as np

x = np.load("X_test.npy")
y = np.load("y_test.npy", allow_pickle='False')

aa = 1